package mycards;

public class Card {
    private final int value; // 1 to 13
    private final int suit;  // 0 to 3

    public Card(int theValue, int theSuit) {
        value = theValue;
        suit = theSuit;
    }

    public int getValue() {
        return value;
    }

    public String toString() {
        String[] suits = {"Spades", "Hearts", "Diamonds", "Clubs"};
        String[] ranks = {null, "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
        return ranks[value] + " of " + suits[suit];
    }
}