package mycards;
import java.util.Scanner;

public class HighLow {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Deck myDeck = new Deck();
        myDeck.shuffle();

        int score = 0;
        Card currentCard = myDeck.dealCard();
        System.out.println("The first card is the " + currentCard);

        while (true) {
            System.out.print("Will the next card be higher (H) or lower (L)? ");
            char guess = input.next().toUpperCase().charAt(0);

            Card nextCard = myDeck.dealCard();
            System.out.println("The next card is the " + nextCard);

            if (nextCard.getValue() == currentCard.getValue()) {
                System.out.println("The values are equal. You lose on ties!");
                break;
            } else if ((nextCard.getValue() > currentCard.getValue() && guess == 'H') ||
                    (nextCard.getValue() < currentCard.getValue() && guess == 'L')) {
                score++;
                System.out.println("You're right! Your current score is " + score + ".\n");
                currentCard = nextCard;
            } else {
                System.out.println("Incorrect guess. Game over!");
                break;
            }
        }
        System.out.println("Your final score: " + score);
    }
}