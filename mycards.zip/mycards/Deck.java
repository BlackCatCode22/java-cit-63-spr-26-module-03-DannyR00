package mycards;

public class Deck {
    private Card[] deck;
    private int cardsUsed;

    public Deck() {
        deck = new Card[52];
        int count = 0;
        for (int s = 0; s <= 3; s++) {
            for (int v = 1; v <= 13; v++) {
                deck[count] = new Card(v, s);
                count++;
            }
        }
        cardsUsed = 0;
    }

    public void shuffle() {
        for (int i = 51; i > 0; i--) {
            int rand = (int)(Math.random() * (i + 1));
            Card temp = deck[i];
            deck[i] = deck[rand];
            deck[rand] = temp;
        }
        cardsUsed = 0;
    }

    public Card dealCard() {
        if (cardsUsed == 52) return null;
        cardsUsed++;
        return deck[cardsUsed - 1];
    }
}