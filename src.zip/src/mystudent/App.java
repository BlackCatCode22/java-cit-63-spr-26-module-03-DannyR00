package mystudent;

public class App {
    public static void main(String[] args) {
        Student s1 = new Student("Your Name", 4.0);
        System.out.println("Student Name: " + s1.name);
        System.out.println("Student GPA: " + s1.gpa);
    }
}