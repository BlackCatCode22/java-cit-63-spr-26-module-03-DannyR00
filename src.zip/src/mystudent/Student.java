package mystudent;

public class Student {
    String name;
    double gpa;

    // The Constructor
    public Student(String name, double gpa) {
        this.name = name;
        this.gpa = gpa;
    }
}