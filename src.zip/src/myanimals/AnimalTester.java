package myanimals;

public class AnimalTester {
    public static void main(String[] args) {
        System.out.println("Starting animal count: " + Animal.numOfAnimals);

        Cat myCat = new Cat();
        Dog myDog = new Dog();
        Cat anotherCat = new Cat();

        System.out.println("Final animal count: " + Animal.numOfAnimals);
    }
}