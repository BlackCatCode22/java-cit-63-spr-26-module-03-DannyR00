package myanimals;

public class Animal {
    // static means this variable belongs to the Class, not the individual object
    public static int numOfAnimals = 0;

    public Animal() {
        // Every time any animal is created, we add 1 to the total
        numOfAnimals++;
    }
}