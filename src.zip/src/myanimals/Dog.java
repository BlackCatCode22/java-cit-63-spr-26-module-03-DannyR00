package myanimals;

public class Dog extends Animal {
    public Dog() {
        super(); // This also updates the same counter in Animal
        System.out.println("A new Dog was created! Current total: " + numOfAnimals);
    }
}