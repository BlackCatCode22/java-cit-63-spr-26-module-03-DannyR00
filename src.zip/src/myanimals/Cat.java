package myanimals;

public class Cat extends Animal {
    public Cat() {
        super(); // This calls the code inside the Animal() constructor
        System.out.println("A new Cat was created! Current total: " + numOfAnimals);
    }
}